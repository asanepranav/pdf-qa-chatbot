"""
rag_pipeline.py — Core RAG logic

Flow:
  PDF → chunks → HuggingFace embeddings → FAISS index
  Question → embed → retrieve top-k chunks → Gemini → answer + sources
"""

import os
import tempfile

from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate


# ── Embedding model (runs locally, no API key needed) ─────────────────────────
EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# ── Prompt ────────────────────────────────────────────────────────────────────
PROMPT_TEMPLATE = """You are a helpful assistant that answers questions based strictly on the provided document context.

Context from the document:
{context}

Question: {question}

Instructions:
- Answer based only on the context above.
- If the answer isn't in the context, say "I couldn't find this in the document."
- Be concise but complete.
- Cite relevant parts naturally in your answer.

Answer:"""


def build_vectorstore(uploaded_file):
    """
    Takes a Streamlit UploadedFile, returns a FAISS vectorstore.
    """
    # Save uploaded file to a temp location (PyPDFLoader needs a file path)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(uploaded_file.read())
        tmp_path = tmp.name

    # 1. Load PDF
    loader = PyPDFLoader(tmp_path)
    documents = loader.load()

    # 2. Split into chunks
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,       # ~1000 chars per chunk
        chunk_overlap=200,     # 200 char overlap to preserve context at boundaries
        separators=["\n\n", "\n", ".", " "]
    )
    chunks = splitter.split_documents(documents)

    # 3. Embed with HuggingFace (runs locally — no API key needed)
    embeddings = HuggingFaceEmbeddings(
        model_name=EMBED_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True}
    )

    # 4. Store in FAISS
    vectorstore = FAISS.from_documents(chunks, embeddings)

    # Cleanup temp file
    os.unlink(tmp_path)

    return vectorstore


def get_answer(vectorstore, question: str) -> dict:
    """
    Given a vectorstore and a question, returns:
      { "answer": str, "sources": [{"text": str, "page": int}] }
    """
    # LLM — Gemini (free tier works well)
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-flash",
        temperature=0.2,        # Low temp = more factual
        google_api_key=os.environ.get("GOOGLE_API_KEY")
    )

    # Prompt
    prompt = PromptTemplate(
        template=PROMPT_TEMPLATE,
        input_variables=["context", "question"]
    )

    # Retrieval chain
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",         # "stuff" = all chunks go in one prompt
        retriever=vectorstore.as_retriever(
            search_type="similarity",
            search_kwargs={"k": 4}  # retrieve top 4 most relevant chunks
        ),
        return_source_documents=True,
        chain_type_kwargs={"prompt": prompt}
    )

    result = qa_chain.invoke({"query": question})

    # Extract sources
    sources = []
    for doc in result.get("source_documents", []):
        sources.append({
            "text": doc.page_content,
            "page": doc.metadata.get("page", "?") + 1  # 0-indexed → 1-indexed
        })

    return {
        "answer": result["result"],
        "sources": sources
    }
